# 🏛️ RAJASTHAN EXAM PORTAL

Complete working website for Rajasthan Government / Competitive Exams — Notifications, Notes, PDFs, Syllabus, Previous Papers, Answer Keys, Results, Admit Cards & Current Affairs.

**Technology:** Python + Flask + SQLite + HTML5 + CSS3 + JavaScript

---

## 1. ZIP Extract कैसे करें

1. `RAJASTHAN_EXAM_PORTAL.zip` को डाउनलोड करें
2. किसी फोल्डर में extract करें (Right click → Extract)
3. Extract होने के बाद `RAJASTHAN_EXAM_PORTAL` फोल्डर खुलेगा

---

## 2. Python Install कैसे करें

### Windows
- https://www.python.org/downloads/ से Python 3.10+ डाउनलोड करें
- Install करते समय **"Add Python to PATH"** जरूर चेक करें

### Android / Termux
```bash
pkg update && pkg upgrade
pkg install python
```

### Linux
```bash
sudo apt update
sudo apt install python3 python3-pip python3-venv
```

---

## 3. Requirements Install कैसे करें

Terminal / Command Prompt में project folder में जाएं:

```bash
cd RAJASTHAN_EXAM_PORTAL
```

Virtual environment (recommended):
```bash
python -m venv venv

# Windows:
venv\Scripts\activate

# Linux / Termux / Mac:
source venv/bin/activate
```

Install packages:
```bash
pip install -r requirements.txt
```

Termux में अगर pip slow हो तो:
```bash
pip install Flask Werkzeug
```

---

## 4. Database कैसे Initialize होगा

पहली बार `python app.py` चलाने पर database **अपने आप** बन जाएगा।

- Location: `instance/database.db`
- Default admin account automatically create हो जाएगा
- Sample data (notifications, notes, current affairs आदि) भी load हो जाएगा

---

## 5. Website कैसे Run करें

```bash
cd RAJASTHAN_EXAM_PORTAL
python app.py
```

Output में दिखेगा:
```
Database initialized successfully!
 * Running on http://0.0.0.0:5000
```

---

## 6. Android / Termux में कैसे Run करें

```bash
# Termux खोलें
pkg update
pkg install python
cd storage/shared/   # या जहाँ ZIP extract किया
cd RAJASTHAN_EXAM_PORTAL
pip install -r requirements.txt
python app.py
```

Phone browser में खोलें: `http://127.0.0.1:5000`

अगर दूसरे device से access करना हो तो phone का IP use करें (Termux में `ifconfig` से IP देखें)।

---

## 7. Browser में कैसे खोलें

Computer पर:
- http://127.0.0.1:5000
- या http://localhost:5000

Mobile (same device): http://127.0.0.1:5000

---

## 8. Admin Panel कैसे खोलें

Browser में जाएं:
```
http://127.0.0.1:5000/admin-panel/login
```

---

## 9. Admin Login Credentials

| Field    | Value        |
|----------|--------------|
| Username | `Mahipal`    |
| Password | `rajraj@123` |

Password database में **hashed** रूप में store होता है (plain text नहीं)।

Credentials बदलने के लिए:
1. Admin login करें
2. या `app.py` में `init_db()` function में username/password बदलकर database delete करके दोबारा run करें

---

## 10. PDF कैसे Upload करें

1. Admin panel login करें
2. Sidebar से **PDFs** → **+ Upload PDF**
3. Title, Category, Description भरें
4. PDF file select करें (केवल .pdf, max 16 MB)
5. Upload करें

PDF `static/uploads/pdfs/` folder में secure नाम से save होती है।

इसी तरह Previous Papers, Syllabus, Answer Keys, Results में भी PDF upload कर सकते हैं।

---

## 11. Website को Public / Internet पर Deploy कैसे करें

### Option A: PythonAnywhere (Free)
1. https://www.pythonanywhere.com पर account बनाएं
2. Files upload करें
3. Web tab में Flask app configure करें
4. WSGI file में `app` object point करें

### Option B: Render / Railway / Fly.io
1. GitHub पर repo push करें
2. Platform से connect करें
3. Start command: `python app.py` या `gunicorn app:app`
4. (Production में gunicorn use करें: `pip install gunicorn`)

### Option C: VPS (DigitalOcean / AWS)
```bash
pip install gunicorn
gunicorn -w 4 -b 0.0.0.0:8000 app:app
```

**Important for production:**
- `config.py` में `SECRET_KEY` change करें
- `debug=False` करें
- HTTPS enable करें

---

## Project Structure

```
RAJASTHAN_EXAM_PORTAL/
├── app.py                 # Main Flask application
├── config.py              # Configuration
├── requirements.txt       # Python packages
├── README.md              # This file
├── instance/
│   └── database.db        # SQLite database (auto-created)
├── static/
│   ├── css/style.css
│   ├── js/script.js
│   ├── images/
│   └── uploads/pdfs/      # Uploaded PDFs
└── templates/
    ├── base.html
    ├── index.html
    ├── notifications.html
    ├── notes.html
    ├── ...
    └── admin/
        ├── login.html
        ├── dashboard.html
        └── ...
```

---

## Features

- ✅ Fully responsive (Mobile / Tablet / Desktop)
- ✅ Admin panel with session authentication
- ✅ Password hashing
- ✅ CRUD for all content types
- ✅ PDF upload & download
- ✅ Search system
- ✅ Sample data included
- ✅ Works on Android Termux

---

**Created by: TIGER**
