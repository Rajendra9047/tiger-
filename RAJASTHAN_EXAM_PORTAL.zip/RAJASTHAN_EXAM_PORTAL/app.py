import os
import sqlite3
import hashlib
import secrets
from datetime import datetime, timedelta
from functools import wraps
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
from flask import (
    Flask, render_template, request, redirect, url_for, flash,
    session, send_from_directory, abort, g, jsonify
)

app = Flask(__name__)
app.config.from_object('config.Config')

# Ensure folders exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(os.path.join(os.path.dirname(__file__), 'instance'), exist_ok=True)

DATABASE = os.path.join(os.path.dirname(__file__), 'instance', 'database.db')


def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys = ON")
    return db


@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()


def init_db():
    db = sqlite3.connect(DATABASE)
    db.row_factory = sqlite3.Row
    cursor = db.cursor()

    # Admins table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS admins (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # Categories table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            slug TEXT UNIQUE NOT NULL,
            description TEXT,
            icon TEXT DEFAULT '📚',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # Notifications table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            exam_name TEXT NOT NULL,
            department TEXT,
            post_name TEXT,
            vacancy TEXT,
            application_start TEXT,
            last_date TEXT,
            exam_date TEXT,
            notification_pdf TEXT,
            apply_link TEXT,
            status TEXT DEFAULT 'Active',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # Notes table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS notes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            category_id INTEGER,
            description TEXT,
            content TEXT,
            pdf_file TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
        )
    ''')

    # PDFs table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS pdfs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            category TEXT,
            description TEXT,
            filename TEXT DEFAULT '',
            upload_date TEXT DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # Previous papers table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS previous_papers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            exam_name TEXT NOT NULL,
            year INTEGER,
            paper_name TEXT,
            description TEXT,
            filename TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # Syllabus table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS syllabus (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            exam_name TEXT NOT NULL,
            subjects TEXT,
            exam_pattern TEXT,
            filename TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # Answer keys table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS answer_keys (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            exam_name TEXT NOT NULL,
            exam_date TEXT,
            paper TEXT,
            filename TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # Results table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            exam_name TEXT NOT NULL,
            result_date TEXT,
            filename TEXT,
            official_link TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # Admit cards table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS admit_cards (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            exam_name TEXT NOT NULL,
            release_date TEXT,
            admit_card_link TEXT,
            official_website TEXT,
            instructions TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # Current affairs table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS current_affairs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT,
            important_facts TEXT,
            affair_date TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # Create default admin if not exists
    cursor.execute("SELECT id FROM admins WHERE username = ?", ('Mahipal',))
    if not cursor.fetchone():
        password_hash = generate_password_hash('rajraj@123')
        cursor.execute(
            "INSERT INTO admins (username, password_hash) VALUES (?, ?)",
            ('Mahipal', password_hash)
        )

    # Sample categories
    categories = [
        ('Rajasthan History', 'rajasthan-history', 'History of Rajasthan', '🏰'),
        ('Rajasthan Geography', 'rajasthan-geography', 'Geography of Rajasthan', '🗺️'),
        ('Rajasthan Art & Culture', 'rajasthan-art-culture', 'Art and Culture of Rajasthan', '🎨'),
        ('Rajasthan Polity', 'rajasthan-polity', 'Polity of Rajasthan', '⚖️'),
        ('Rajasthan Economy', 'rajasthan-economy', 'Economy of Rajasthan', '💰'),
        ('General Knowledge', 'general-knowledge', 'General Knowledge', '🧠'),
        ('Current Affairs', 'current-affairs-notes', 'Current Affairs Notes', '📰'),
        ('Hindi', 'hindi', 'Hindi Language', '📖'),
        ('English', 'english', 'English Language', '🔤'),
        ('Reasoning', 'reasoning', 'Reasoning Ability', '🧩'),
        ('Mathematics', 'mathematics', 'Mathematics', '🔢'),
        ('Science', 'science', 'Science', '🔬'),
        ('Computer', 'computer', 'Computer Knowledge', '💻'),
    ]
    for name, slug, desc, icon in categories:
        cursor.execute(
            "INSERT OR IGNORE INTO categories (name, slug, description, icon) VALUES (?, ?, ?, ?)",
            (name, slug, desc, icon)
        )

    # Sample notifications
    cursor.execute("SELECT COUNT(*) FROM notifications")
    if cursor.fetchone()[0] == 0:
        samples = [
            ('RPSC RAS 2024', 'Rajasthan Public Service Commission', 'RAS/RTS', '1000+', '2024-01-15', '2024-02-28', '2024-06-15', None, 'https://rpsc.rajasthan.gov.in', 'Active'),
            ('REET 2024', 'Rajasthan Board of Secondary Education', 'Teacher Level 1 & 2', '48000+', '2024-03-01', '2024-04-15', '2024-07-20', None, 'https://rajeduboard.rajasthan.gov.in', 'Active'),
            ('RSMSSB Patwari 2024', 'Rajasthan Staff Selection Board', 'Patwari', '5000+', '2024-02-10', '2024-03-20', '2024-08-10', None, 'https://rsmssb.rajasthan.gov.in', 'Coming Soon'),
            ('Rajasthan Police Constable 2024', 'Rajasthan Police', 'Constable', '3500+', '2024-01-20', '2024-02-25', '2024-05-30', None, 'https://police.rajasthan.gov.in', 'Closed'),
            ('RPSC School Lecturer 2024', 'Rajasthan Public Service Commission', 'School Lecturer', '2000+', '2024-04-01', '2024-05-15', '2024-09-01', None, 'https://rpsc.rajasthan.gov.in', 'Active'),
        ]
        for s in samples:
            cursor.execute('''
                INSERT INTO notifications (exam_name, department, post_name, vacancy, application_start, last_date, exam_date, notification_pdf, apply_link, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', s)

    # Sample current affairs
    cursor.execute("SELECT COUNT(*) FROM current_affairs")
    if cursor.fetchone()[0] == 0:
        ca_samples = [
            ('Rajasthan Budget 2024-25 Highlights', 'Rajasthan government presented the state budget focusing on education, health and employment.', 'Education allocation increased by 15%. New schemes for youth employment announced.', '2024-02-10'),
            ('RPSC New Exam Calendar Released', 'Rajasthan Public Service Commission released the annual exam calendar for 2024.', 'RAS prelims scheduled in June. Multiple recruitment notifications expected.', '2024-01-25'),
            ('Rajasthan Free Education Scheme Expansion', 'State government expanded free education scheme for girls up to higher secondary.', 'Free textbooks and uniforms for all girl students in government schools.', '2024-03-05'),
            ('Jaipur Metro Phase-2 Progress', 'Jaipur Metro Phase-2 construction progressing rapidly with new stations planned.', 'Expected completion by end of 2025. Will connect more areas of Jaipur.', '2024-02-28'),
            ('Rajasthan Water Conservation Initiative', 'New water conservation projects launched across desert districts of Rajasthan.', 'Focus on rainwater harvesting and traditional water bodies restoration.', '2024-03-12'),
        ]
        for title, desc, facts, date in ca_samples:
            cursor.execute(
                "INSERT INTO current_affairs (title, description, important_facts, affair_date) VALUES (?, ?, ?, ?)",
                (title, desc, facts, date)
            )

    # Sample previous papers
    cursor.execute("SELECT COUNT(*) FROM previous_papers")
    if cursor.fetchone()[0] == 0:
        papers = [
            ('RPSC RAS', 2023, 'Prelims Paper 1', 'RAS Prelims 2023 Paper'),
            ('RPSC RAS', 2022, 'Prelims Paper 1', 'RAS Prelims 2022 Paper'),
            ('REET', 2023, 'Level 1', 'REET Level 1 2023'),
            ('REET', 2022, 'Level 2', 'REET Level 2 2022'),
            ('RSMSSB Patwari', 2021, 'Paper 1', 'Patwari 2021 Paper'),
            ('Rajasthan Police', 2022, 'Constable Paper', 'Police Constable 2022'),
            ('RPSC LDC', 2023, 'Paper 1', 'LDC 2023 Paper'),
            ('CET', 2023, 'Graduation Level', 'CET Graduation 2023'),
        ]
        for exam, year, paper, desc in papers:
            cursor.execute(
                "INSERT INTO previous_papers (exam_name, year, paper_name, description) VALUES (?, ?, ?, ?)",
                (exam, year, paper, desc)
            )

    # Sample syllabus
    cursor.execute("SELECT COUNT(*) FROM syllabus")
    if cursor.fetchone()[0] == 0:
        syllabi = [
            ('RPSC RAS', 'History, Geography, Polity, Economy, Science, Current Affairs', 'Prelims: Objective, Mains: Descriptive'),
            ('REET Level 1', 'Child Development, Language, Mathematics, EVS', 'Objective type, 150 questions'),
            ('REET Level 2', 'Child Development, Language, Subject Specific', 'Objective type, 150 questions'),
            ('RSMSSB Patwari', 'General Knowledge, Rajasthan GK, Maths, Reasoning', 'Objective type'),
            ('Rajasthan Police Constable', 'General Knowledge, Reasoning, Maths, Rajasthan GK', 'Objective + Physical'),
        ]
        for exam, subjects, pattern in syllabi:
            cursor.execute(
                "INSERT INTO syllabus (exam_name, subjects, exam_pattern) VALUES (?, ?, ?)",
                (exam, subjects, pattern)
            )

    # Sample answer keys
    cursor.execute("SELECT COUNT(*) FROM answer_keys")
    if cursor.fetchone()[0] == 0:
        keys = [
            ('RPSC RAS Prelims 2023', '2023-06-20', 'Paper 1'),
            ('REET 2023 Level 1', '2023-07-15', 'Level 1'),
            ('RSMSSB Patwari 2021', '2021-09-10', 'Paper 1'),
        ]
        for exam, date, paper in keys:
            cursor.execute(
                "INSERT INTO answer_keys (exam_name, exam_date, paper) VALUES (?, ?, ?)",
                (exam, date, paper)
            )

    # Sample results
    cursor.execute("SELECT COUNT(*) FROM results")
    if cursor.fetchone()[0] == 0:
        results = [
            ('RPSC RAS 2023 Final Result', '2023-12-15', 'https://rpsc.rajasthan.gov.in'),
            ('REET 2023 Result', '2023-10-20', 'https://rajeduboard.rajasthan.gov.in'),
            ('Rajasthan Police Constable 2022', '2023-03-10', 'https://police.rajasthan.gov.in'),
        ]
        for exam, date, link in results:
            cursor.execute(
                "INSERT INTO results (exam_name, result_date, official_link) VALUES (?, ?, ?)",
                (exam, date, link)
            )

    # Sample admit cards
    cursor.execute("SELECT COUNT(*) FROM admit_cards")
    if cursor.fetchone()[0] == 0:
        admits = [
            ('RPSC RAS Prelims 2024', '2024-05-20', 'https://rpsc.rajasthan.gov.in', 'https://rpsc.rajasthan.gov.in', 'Carry original ID proof and print of admit card.'),
            ('REET 2024', '2024-06-25', 'https://rajeduboard.rajasthan.gov.in', 'https://rajeduboard.rajasthan.gov.in', 'Reach exam center 1 hour before. No electronic devices allowed.'),
        ]
        for exam, date, link, official, instr in admits:
            cursor.execute(
                "INSERT INTO admit_cards (exam_name, release_date, admit_card_link, official_website, instructions) VALUES (?, ?, ?, ?, ?)",
                (exam, date, link, official, instr)
            )

    # Sample notes
    cursor.execute("SELECT COUNT(*) FROM notes")
    if cursor.fetchone()[0] == 0:
        cursor.execute("SELECT id FROM categories WHERE slug = 'rajasthan-history'")
        hist = cursor.fetchone()
        cursor.execute("SELECT id FROM categories WHERE slug = 'rajasthan-geography'")
        geo = cursor.fetchone()
        notes_data = [
            ('History of Rajasthan - Complete Notes', hist['id'] if hist else None, 'Comprehensive notes on Rajasthan history from ancient to modern period.', 'Ancient Rajput kingdoms, Mughal period, British rule, freedom movement in Rajasthan.'),
            ('Geography of Rajasthan - Key Points', geo['id'] if geo else None, 'Important geographical features of Rajasthan.', 'Aravalli range, Thar desert, major rivers, climate, soil types, mineral resources.'),
            ('Rajasthan Polity Basics', None, 'State government structure and important constitutional points related to Rajasthan.', 'Governor, CM, Legislature, High Court, Local bodies.'),
        ]
        for title, cat_id, desc, content in notes_data:
            cursor.execute(
                "INSERT INTO notes (title, category_id, description, content) VALUES (?, ?, ?, ?)",
                (title, cat_id, desc, content)
            )

    # Sample PDFs (metadata only, no actual files)
    cursor.execute("SELECT COUNT(*) FROM pdfs")
    if cursor.fetchone()[0] == 0:
        pdf_samples = [
            ('Rajasthan GK Complete PDF', 'General Knowledge', 'Complete Rajasthan General Knowledge PDF for all exams.'),
            ('RPSC RAS Syllabus PDF', 'Syllabus', 'Official RAS syllabus PDF.'),
            ('REET Child Development Notes', 'Notes', 'Child development and pedagogy notes for REET.'),
        ]
        for title, cat, desc in pdf_samples:
            cursor.execute(
                "INSERT INTO pdfs (title, category, description, filename) VALUES (?, ?, ?, ?)",
                (title, cat, desc, '')
            )

    db.commit()
    db.close()
    print("Database initialized successfully!")


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']


def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'admin_id' not in session:
            flash('Please login to access admin panel.', 'warning')
            return redirect(url_for('admin_login'))
        return f(*args, **kwargs)
    return decorated_function


def get_stats():
    db = get_db()
    stats = {
        'notifications': db.execute("SELECT COUNT(*) FROM notifications").fetchone()[0],
        'pdfs': db.execute("SELECT COUNT(*) FROM pdfs").fetchone()[0],
        'notes': db.execute("SELECT COUNT(*) FROM notes").fetchone()[0],
        'papers': db.execute("SELECT COUNT(*) FROM previous_papers").fetchone()[0],
        'syllabus': db.execute("SELECT COUNT(*) FROM syllabus").fetchone()[0],
        'results': db.execute("SELECT COUNT(*) FROM results").fetchone()[0],
        'answer_keys': db.execute("SELECT COUNT(*) FROM answer_keys").fetchone()[0],
        'admit_cards': db.execute("SELECT COUNT(*) FROM admit_cards").fetchone()[0],
        'current_affairs': db.execute("SELECT COUNT(*) FROM current_affairs").fetchone()[0],
        'categories': db.execute("SELECT COUNT(*) FROM categories").fetchone()[0],
    }
    return stats


# ==================== PUBLIC ROUTES ====================

@app.route('/')
def index():
    db = get_db()
    latest_notifications = db.execute(
        "SELECT * FROM notifications ORDER BY created_at DESC LIMIT 5"
    ).fetchall()
    latest_affairs = db.execute(
        "SELECT * FROM current_affairs ORDER BY affair_date DESC LIMIT 5"
    ).fetchall()
    return render_template('index.html',
                           notifications=latest_notifications,
                           affairs=latest_affairs)


@app.route('/notifications')
def notifications():
    db = get_db()
    status_filter = request.args.get('status', '')
    query = "SELECT * FROM notifications"
    params = []
    if status_filter:
        query += " WHERE status = ?"
        params.append(status_filter)
    query += " ORDER BY created_at DESC"
    items = db.execute(query, params).fetchall()
    return render_template('notifications.html', notifications=items, status_filter=status_filter)


@app.route('/notes')
def notes():
    db = get_db()
    categories = db.execute("SELECT * FROM categories ORDER BY name").fetchall()
    return render_template('notes.html', categories=categories)


@app.route('/notes/<slug>')
def notes_category(slug):
    db = get_db()
    category = db.execute("SELECT * FROM categories WHERE slug = ?", (slug,)).fetchone()
    if not category:
        abort(404)
    notes_list = db.execute(
        "SELECT * FROM notes WHERE category_id = ? ORDER BY created_at DESC",
        (category['id'],)
    ).fetchall()
    return render_template('notes_category.html', category=category, notes=notes_list)


@app.route('/pdfs')
def pdfs():
    db = get_db()
    category = request.args.get('category', '')
    query = "SELECT * FROM pdfs"
    params = []
    if category:
        query += " WHERE category = ?"
        params.append(category)
    query += " ORDER BY upload_date DESC"
    items = db.execute(query, params).fetchall()
    categories = db.execute("SELECT DISTINCT category FROM pdfs WHERE category IS NOT NULL AND category != ''").fetchall()
    return render_template('pdfs.html', pdfs=items, categories=categories, selected_category=category)


@app.route('/previous-papers')
def previous_papers():
    db = get_db()
    exam = request.args.get('exam', '')
    year = request.args.get('year', '')
    query = "SELECT * FROM previous_papers WHERE 1=1"
    params = []
    if exam:
        query += " AND exam_name LIKE ?"
        params.append(f'%{exam}%')
    if year:
        query += " AND year = ?"
        params.append(year)
    query += " ORDER BY year DESC, exam_name"
    items = db.execute(query, params).fetchall()
    exams = db.execute("SELECT DISTINCT exam_name FROM previous_papers ORDER BY exam_name").fetchall()
    years = db.execute("SELECT DISTINCT year FROM previous_papers ORDER BY year DESC").fetchall()
    return render_template('previous_papers.html', papers=items, exams=exams, years=years,
                           selected_exam=exam, selected_year=year)


@app.route('/syllabus')
def syllabus():
    db = get_db()
    items = db.execute("SELECT * FROM syllabus ORDER BY exam_name").fetchall()
    return render_template('syllabus.html', syllabus_list=items)


@app.route('/answer-keys')
def answer_keys():
    db = get_db()
    items = db.execute("SELECT * FROM answer_keys ORDER BY exam_date DESC").fetchall()
    return render_template('answer_keys.html', answer_keys=items)


@app.route('/results')
def results():
    db = get_db()
    items = db.execute("SELECT * FROM results ORDER BY result_date DESC").fetchall()
    return render_template('results.html', results=items)


@app.route('/admit-card')
def admit_card():
    db = get_db()
    items = db.execute("SELECT * FROM admit_cards ORDER BY release_date DESC").fetchall()
    return render_template('admit_card.html', admit_cards=items)


@app.route('/current-affairs')
def current_affairs():
    db = get_db()
    items = db.execute("SELECT * FROM current_affairs ORDER BY affair_date DESC").fetchall()
    return render_template('current_affairs.html', affairs=items)


@app.route('/search')
def search():
    q = request.args.get('q', '').strip()
    results = {'notifications': [], 'notes': [], 'pdfs': [], 'papers': [], 'syllabus': [],
               'answer_keys': [], 'results': [], 'admit_cards': [], 'current_affairs': []}
    if q:
        db = get_db()
        like = f'%{q}%'
        results['notifications'] = db.execute(
            "SELECT * FROM notifications WHERE exam_name LIKE ? OR department LIKE ? OR post_name LIKE ?",
            (like, like, like)
        ).fetchall()
        results['notes'] = db.execute(
            "SELECT n.*, c.name as category_name FROM notes n LEFT JOIN categories c ON n.category_id = c.id WHERE n.title LIKE ? OR n.description LIKE ?",
            (like, like)
        ).fetchall()
        results['pdfs'] = db.execute(
            "SELECT * FROM pdfs WHERE title LIKE ? OR category LIKE ? OR description LIKE ?",
            (like, like, like)
        ).fetchall()
        results['papers'] = db.execute(
            "SELECT * FROM previous_papers WHERE exam_name LIKE ? OR paper_name LIKE ?",
            (like, like)
        ).fetchall()
        results['syllabus'] = db.execute(
            "SELECT * FROM syllabus WHERE exam_name LIKE ? OR subjects LIKE ?",
            (like, like)
        ).fetchall()
        results['answer_keys'] = db.execute(
            "SELECT * FROM answer_keys WHERE exam_name LIKE ?",
            (like,)
        ).fetchall()
        results['results'] = db.execute(
            "SELECT * FROM results WHERE exam_name LIKE ?",
            (like,)
        ).fetchall()
        results['admit_cards'] = db.execute(
            "SELECT * FROM admit_cards WHERE exam_name LIKE ?",
            (like,)
        ).fetchall()
        results['current_affairs'] = db.execute(
            "SELECT * FROM current_affairs WHERE title LIKE ? OR description LIKE ?",
            (like, like)
        ).fetchall()
    total = sum(len(v) for v in results.values())
    return render_template('search.html', query=q, results=results, total=total)


@app.route('/contact')
def contact():
    return render_template('contact.html')


@app.route('/privacy')
def privacy():
    return render_template('privacy.html')


@app.route('/terms')
def terms():
    return render_template('terms.html')


@app.route('/uploads/pdfs/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)


# ==================== ADMIN ROUTES ====================

@app.route('/admin-panel/login', methods=['GET', 'POST'])
def admin_login():
    if 'admin_id' in session:
        return redirect(url_for('admin_dashboard'))
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        db = get_db()
        admin = db.execute("SELECT * FROM admins WHERE username = ?", (username,)).fetchone()
        if admin and check_password_hash(admin['password_hash'], password):
            session['admin_id'] = admin['id']
            session['admin_username'] = admin['username']
            session.permanent = True
            flash('Login successful!', 'success')
            return redirect(url_for('admin_dashboard'))
        flash('Invalid username or password.', 'danger')
    return render_template('admin/login.html')


@app.route('/admin-panel/logout')
def admin_logout():
    session.clear()
    flash('Logged out successfully.', 'info')
    return redirect(url_for('admin_login'))


@app.route('/admin-panel/dashboard')
@login_required
def admin_dashboard():
    stats = get_stats()
    return render_template('admin/dashboard.html', stats=stats)


# ----- Notifications CRUD -----
@app.route('/admin-panel/notifications')
@login_required
def admin_notifications():
    db = get_db()
    items = db.execute("SELECT * FROM notifications ORDER BY created_at DESC").fetchall()
    return render_template('admin/notifications.html', notifications=items)


@app.route('/admin-panel/notifications/add', methods=['GET', 'POST'])
@login_required
def admin_notifications_add():
    if request.method == 'POST':
        db = get_db()
        db.execute('''
            INSERT INTO notifications (exam_name, department, post_name, vacancy, application_start, last_date, exam_date, apply_link, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            request.form.get('exam_name'),
            request.form.get('department'),
            request.form.get('post_name'),
            request.form.get('vacancy'),
            request.form.get('application_start'),
            request.form.get('last_date'),
            request.form.get('exam_date'),
            request.form.get('apply_link'),
            request.form.get('status', 'Active')
        ))
        db.commit()
        flash('Notification added successfully!', 'success')
        return redirect(url_for('admin_notifications'))
    return render_template('admin/notification_form.html', notification=None)


@app.route('/admin-panel/notifications/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def admin_notifications_edit(id):
    db = get_db()
    notification = db.execute("SELECT * FROM notifications WHERE id = ?", (id,)).fetchone()
    if not notification:
        abort(404)
    if request.method == 'POST':
        db.execute('''
            UPDATE notifications SET exam_name=?, department=?, post_name=?, vacancy=?,
            application_start=?, last_date=?, exam_date=?, apply_link=?, status=?, updated_at=CURRENT_TIMESTAMP
            WHERE id=?
        ''', (
            request.form.get('exam_name'),
            request.form.get('department'),
            request.form.get('post_name'),
            request.form.get('vacancy'),
            request.form.get('application_start'),
            request.form.get('last_date'),
            request.form.get('exam_date'),
            request.form.get('apply_link'),
            request.form.get('status', 'Active'),
            id
        ))
        db.commit()
        flash('Notification updated!', 'success')
        return redirect(url_for('admin_notifications'))
    return render_template('admin/notification_form.html', notification=notification)


@app.route('/admin-panel/notifications/delete/<int:id>', methods=['POST'])
@login_required
def admin_notifications_delete(id):
    db = get_db()
    db.execute("DELETE FROM notifications WHERE id = ?", (id,))
    db.commit()
    flash('Notification deleted!', 'success')
    return redirect(url_for('admin_notifications'))


# ----- Notes CRUD -----
@app.route('/admin-panel/notes')
@login_required
def admin_notes():
    db = get_db()
    items = db.execute(
        "SELECT n.*, c.name as category_name FROM notes n LEFT JOIN categories c ON n.category_id = c.id ORDER BY n.created_at DESC"
    ).fetchall()
    return render_template('admin/notes.html', notes=items)


@app.route('/admin-panel/notes/add', methods=['GET', 'POST'])
@login_required
def admin_notes_add():
    db = get_db()
    categories = db.execute("SELECT * FROM categories ORDER BY name").fetchall()
    if request.method == 'POST':
        cat_id = request.form.get('category_id') or None
        db.execute(
            "INSERT INTO notes (title, category_id, description, content) VALUES (?, ?, ?, ?)",
            (request.form.get('title'), cat_id, request.form.get('description'), request.form.get('content'))
        )
        db.commit()
        flash('Note added!', 'success')
        return redirect(url_for('admin_notes'))
    return render_template('admin/note_form.html', note=None, categories=categories)


@app.route('/admin-panel/notes/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def admin_notes_edit(id):
    db = get_db()
    note = db.execute("SELECT * FROM notes WHERE id = ?", (id,)).fetchone()
    if not note:
        abort(404)
    categories = db.execute("SELECT * FROM categories ORDER BY name").fetchall()
    if request.method == 'POST':
        cat_id = request.form.get('category_id') or None
        db.execute(
            "UPDATE notes SET title=?, category_id=?, description=?, content=? WHERE id=?",
            (request.form.get('title'), cat_id, request.form.get('description'), request.form.get('content'), id)
        )
        db.commit()
        flash('Note updated!', 'success')
        return redirect(url_for('admin_notes'))
    return render_template('admin/note_form.html', note=note, categories=categories)


@app.route('/admin-panel/notes/delete/<int:id>', methods=['POST'])
@login_required
def admin_notes_delete(id):
    db = get_db()
    db.execute("DELETE FROM notes WHERE id = ?", (id,))
    db.commit()
    flash('Note deleted!', 'success')
    return redirect(url_for('admin_notes'))


# ----- PDFs CRUD -----
@app.route('/admin-panel/pdfs')
@login_required
def admin_pdfs():
    db = get_db()
    items = db.execute("SELECT * FROM pdfs ORDER BY upload_date DESC").fetchall()
    return render_template('admin/pdfs.html', pdfs=items)


@app.route('/admin-panel/pdfs/add', methods=['GET', 'POST'])
@login_required
def admin_pdfs_add():
    if request.method == 'POST':
        title = request.form.get('title')
        category = request.form.get('category')
        description = request.form.get('description')
        file = request.files.get('pdf_file')
        filename = ''
        if file and file.filename and allowed_file(file.filename):
            original = secure_filename(file.filename)
            unique = secrets.token_hex(8) + '_' + original
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], unique)
            file.save(filepath)
            filename = unique
        db = get_db()
        db.execute(
            "INSERT INTO pdfs (title, category, description, filename) VALUES (?, ?, ?, ?)",
            (title, category, description, filename)
        )
        db.commit()
        flash('PDF added successfully!', 'success')
        return redirect(url_for('admin_pdfs'))
    return render_template('admin/pdf_form.html', pdf=None)


@app.route('/admin-panel/pdfs/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def admin_pdfs_edit(id):
    db = get_db()
    pdf = db.execute("SELECT * FROM pdfs WHERE id = ?", (id,)).fetchone()
    if not pdf:
        abort(404)
    if request.method == 'POST':
        title = request.form.get('title')
        category = request.form.get('category')
        description = request.form.get('description')
        filename = pdf['filename']
        file = request.files.get('pdf_file')
        if file and file.filename and allowed_file(file.filename):
            if filename:
                old_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                if os.path.exists(old_path):
                    os.remove(old_path)
            original = secure_filename(file.filename)
            unique = secrets.token_hex(8) + '_' + original
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], unique)
            file.save(filepath)
            filename = unique
        db.execute(
            "UPDATE pdfs SET title=?, category=?, description=?, filename=? WHERE id=?",
            (title, category, description, filename, id)
        )
        db.commit()
        flash('PDF updated!', 'success')
        return redirect(url_for('admin_pdfs'))
    return render_template('admin/pdf_form.html', pdf=pdf)


@app.route('/admin-panel/pdfs/delete/<int:id>', methods=['POST'])
@login_required
def admin_pdfs_delete(id):
    db = get_db()
    pdf = db.execute("SELECT * FROM pdfs WHERE id = ?", (id,)).fetchone()
    if pdf and pdf['filename']:
        path = os.path.join(app.config['UPLOAD_FOLDER'], pdf['filename'])
        if os.path.exists(path):
            os.remove(path)
    db.execute("DELETE FROM pdfs WHERE id = ?", (id,))
    db.commit()
    flash('PDF deleted!', 'success')
    return redirect(url_for('admin_pdfs'))


# ----- Previous Papers CRUD -----
@app.route('/admin-panel/papers')
@login_required
def admin_papers():
    db = get_db()
    items = db.execute("SELECT * FROM previous_papers ORDER BY year DESC").fetchall()
    return render_template('admin/papers.html', papers=items)


@app.route('/admin-panel/papers/add', methods=['GET', 'POST'])
@login_required
def admin_papers_add():
    if request.method == 'POST':
        file = request.files.get('pdf_file')
        filename = ''
        if file and file.filename and allowed_file(file.filename):
            original = secure_filename(file.filename)
            unique = secrets.token_hex(8) + '_' + original
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], unique))
            filename = unique
        db = get_db()
        db.execute(
            "INSERT INTO previous_papers (exam_name, year, paper_name, description, filename) VALUES (?, ?, ?, ?, ?)",
            (request.form.get('exam_name'), request.form.get('year'), request.form.get('paper_name'),
             request.form.get('description'), filename)
        )
        db.commit()
        flash('Paper added!', 'success')
        return redirect(url_for('admin_papers'))
    return render_template('admin/paper_form.html', paper=None)


@app.route('/admin-panel/papers/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def admin_papers_edit(id):
    db = get_db()
    paper = db.execute("SELECT * FROM previous_papers WHERE id = ?", (id,)).fetchone()
    if not paper:
        abort(404)
    if request.method == 'POST':
        filename = paper['filename']
        file = request.files.get('pdf_file')
        if file and file.filename and allowed_file(file.filename):
            if filename:
                old = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                if os.path.exists(old):
                    os.remove(old)
            original = secure_filename(file.filename)
            unique = secrets.token_hex(8) + '_' + original
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], unique))
            filename = unique
        db.execute(
            "UPDATE previous_papers SET exam_name=?, year=?, paper_name=?, description=?, filename=? WHERE id=?",
            (request.form.get('exam_name'), request.form.get('year'), request.form.get('paper_name'),
             request.form.get('description'), filename, id)
        )
        db.commit()
        flash('Paper updated!', 'success')
        return redirect(url_for('admin_papers'))
    return render_template('admin/paper_form.html', paper=paper)


@app.route('/admin-panel/papers/delete/<int:id>', methods=['POST'])
@login_required
def admin_papers_delete(id):
    db = get_db()
    paper = db.execute("SELECT * FROM previous_papers WHERE id = ?", (id,)).fetchone()
    if paper and paper['filename']:
        path = os.path.join(app.config['UPLOAD_FOLDER'], paper['filename'])
        if os.path.exists(path):
            os.remove(path)
    db.execute("DELETE FROM previous_papers WHERE id = ?", (id,))
    db.commit()
    flash('Paper deleted!', 'success')
    return redirect(url_for('admin_papers'))


# ----- Syllabus CRUD -----
@app.route('/admin-panel/syllabus')
@login_required
def admin_syllabus():
    db = get_db()
    items = db.execute("SELECT * FROM syllabus ORDER BY exam_name").fetchall()
    return render_template('admin/syllabus.html', syllabus_list=items)


@app.route('/admin-panel/syllabus/add', methods=['GET', 'POST'])
@login_required
def admin_syllabus_add():
    if request.method == 'POST':
        file = request.files.get('pdf_file')
        filename = ''
        if file and file.filename and allowed_file(file.filename):
            original = secure_filename(file.filename)
            unique = secrets.token_hex(8) + '_' + original
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], unique))
            filename = unique
        db = get_db()
        db.execute(
            "INSERT INTO syllabus (exam_name, subjects, exam_pattern, filename) VALUES (?, ?, ?, ?)",
            (request.form.get('exam_name'), request.form.get('subjects'), request.form.get('exam_pattern'), filename)
        )
        db.commit()
        flash('Syllabus added!', 'success')
        return redirect(url_for('admin_syllabus'))
    return render_template('admin/syllabus_form.html', item=None)


@app.route('/admin-panel/syllabus/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def admin_syllabus_edit(id):
    db = get_db()
    item = db.execute("SELECT * FROM syllabus WHERE id = ?", (id,)).fetchone()
    if not item:
        abort(404)
    if request.method == 'POST':
        filename = item['filename']
        file = request.files.get('pdf_file')
        if file and file.filename and allowed_file(file.filename):
            if filename:
                old = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                if os.path.exists(old):
                    os.remove(old)
            original = secure_filename(file.filename)
            unique = secrets.token_hex(8) + '_' + original
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], unique))
            filename = unique
        db.execute(
            "UPDATE syllabus SET exam_name=?, subjects=?, exam_pattern=?, filename=? WHERE id=?",
            (request.form.get('exam_name'), request.form.get('subjects'), request.form.get('exam_pattern'), filename, id)
        )
        db.commit()
        flash('Syllabus updated!', 'success')
        return redirect(url_for('admin_syllabus'))
    return render_template('admin/syllabus_form.html', item=item)


@app.route('/admin-panel/syllabus/delete/<int:id>', methods=['POST'])
@login_required
def admin_syllabus_delete(id):
    db = get_db()
    item = db.execute("SELECT * FROM syllabus WHERE id = ?", (id,)).fetchone()
    if item and item['filename']:
        path = os.path.join(app.config['UPLOAD_FOLDER'], item['filename'])
        if os.path.exists(path):
            os.remove(path)
    db.execute("DELETE FROM syllabus WHERE id = ?", (id,))
    db.commit()
    flash('Syllabus deleted!', 'success')
    return redirect(url_for('admin_syllabus'))


# ----- Answer Keys CRUD -----
@app.route('/admin-panel/answer-keys')
@login_required
def admin_answer_keys():
    db = get_db()
    items = db.execute("SELECT * FROM answer_keys ORDER BY exam_date DESC").fetchall()
    return render_template('admin/answer_keys.html', answer_keys=items)


@app.route('/admin-panel/answer-keys/add', methods=['GET', 'POST'])
@login_required
def admin_answer_keys_add():
    if request.method == 'POST':
        file = request.files.get('pdf_file')
        filename = ''
        if file and file.filename and allowed_file(file.filename):
            original = secure_filename(file.filename)
            unique = secrets.token_hex(8) + '_' + original
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], unique))
            filename = unique
        db = get_db()
        db.execute(
            "INSERT INTO answer_keys (exam_name, exam_date, paper, filename) VALUES (?, ?, ?, ?)",
            (request.form.get('exam_name'), request.form.get('exam_date'), request.form.get('paper'), filename)
        )
        db.commit()
        flash('Answer key added!', 'success')
        return redirect(url_for('admin_answer_keys'))
    return render_template('admin/answer_key_form.html', item=None)


@app.route('/admin-panel/answer-keys/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def admin_answer_keys_edit(id):
    db = get_db()
    item = db.execute("SELECT * FROM answer_keys WHERE id = ?", (id,)).fetchone()
    if not item:
        abort(404)
    if request.method == 'POST':
        filename = item['filename']
        file = request.files.get('pdf_file')
        if file and file.filename and allowed_file(file.filename):
            if filename:
                old = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                if os.path.exists(old):
                    os.remove(old)
            original = secure_filename(file.filename)
            unique = secrets.token_hex(8) + '_' + original
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], unique))
            filename = unique
        db.execute(
            "UPDATE answer_keys SET exam_name=?, exam_date=?, paper=?, filename=? WHERE id=?",
            (request.form.get('exam_name'), request.form.get('exam_date'), request.form.get('paper'), filename, id)
        )
        db.commit()
        flash('Answer key updated!', 'success')
        return redirect(url_for('admin_answer_keys'))
    return render_template('admin/answer_key_form.html', item=item)


@app.route('/admin-panel/answer-keys/delete/<int:id>', methods=['POST'])
@login_required
def admin_answer_keys_delete(id):
    db = get_db()
    item = db.execute("SELECT * FROM answer_keys WHERE id = ?", (id,)).fetchone()
    if item and item['filename']:
        path = os.path.join(app.config['UPLOAD_FOLDER'], item['filename'])
        if os.path.exists(path):
            os.remove(path)
    db.execute("DELETE FROM answer_keys WHERE id = ?", (id,))
    db.commit()
    flash('Answer key deleted!', 'success')
    return redirect(url_for('admin_answer_keys'))


# ----- Results CRUD -----
@app.route('/admin-panel/results')
@login_required
def admin_results():
    db = get_db()
    items = db.execute("SELECT * FROM results ORDER BY result_date DESC").fetchall()
    return render_template('admin/results.html', results=items)


@app.route('/admin-panel/results/add', methods=['GET', 'POST'])
@login_required
def admin_results_add():
    if request.method == 'POST':
        file = request.files.get('pdf_file')
        filename = ''
        if file and file.filename and allowed_file(file.filename):
            original = secure_filename(file.filename)
            unique = secrets.token_hex(8) + '_' + original
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], unique))
            filename = unique
        db = get_db()
        db.execute(
            "INSERT INTO results (exam_name, result_date, filename, official_link) VALUES (?, ?, ?, ?)",
            (request.form.get('exam_name'), request.form.get('result_date'), filename, request.form.get('official_link'))
        )
        db.commit()
        flash('Result added!', 'success')
        return redirect(url_for('admin_results'))
    return render_template('admin/result_form.html', item=None)


@app.route('/admin-panel/results/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def admin_results_edit(id):
    db = get_db()
    item = db.execute("SELECT * FROM results WHERE id = ?", (id,)).fetchone()
    if not item:
        abort(404)
    if request.method == 'POST':
        filename = item['filename']
        file = request.files.get('pdf_file')
        if file and file.filename and allowed_file(file.filename):
            if filename:
                old = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                if os.path.exists(old):
                    os.remove(old)
            original = secure_filename(file.filename)
            unique = secrets.token_hex(8) + '_' + original
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], unique))
            filename = unique
        db.execute(
            "UPDATE results SET exam_name=?, result_date=?, filename=?, official_link=? WHERE id=?",
            (request.form.get('exam_name'), request.form.get('result_date'), filename, request.form.get('official_link'), id)
        )
        db.commit()
        flash('Result updated!', 'success')
        return redirect(url_for('admin_results'))
    return render_template('admin/result_form.html', item=item)


@app.route('/admin-panel/results/delete/<int:id>', methods=['POST'])
@login_required
def admin_results_delete(id):
    db = get_db()
    item = db.execute("SELECT * FROM results WHERE id = ?", (id,)).fetchone()
    if item and item['filename']:
        path = os.path.join(app.config['UPLOAD_FOLDER'], item['filename'])
        if os.path.exists(path):
            os.remove(path)
    db.execute("DELETE FROM results WHERE id = ?", (id,))
    db.commit()
    flash('Result deleted!', 'success')
    return redirect(url_for('admin_results'))


# ----- Admit Cards CRUD -----
@app.route('/admin-panel/admit-cards')
@login_required
def admin_admit_cards():
    db = get_db()
    items = db.execute("SELECT * FROM admit_cards ORDER BY release_date DESC").fetchall()
    return render_template('admin/admit_cards.html', admit_cards=items)


@app.route('/admin-panel/admit-cards/add', methods=['GET', 'POST'])
@login_required
def admin_admit_cards_add():
    if request.method == 'POST':
        db = get_db()
        db.execute(
            "INSERT INTO admit_cards (exam_name, release_date, admit_card_link, official_website, instructions) VALUES (?, ?, ?, ?, ?)",
            (request.form.get('exam_name'), request.form.get('release_date'), request.form.get('admit_card_link'),
             request.form.get('official_website'), request.form.get('instructions'))
        )
        db.commit()
        flash('Admit card added!', 'success')
        return redirect(url_for('admin_admit_cards'))
    return render_template('admin/admit_card_form.html', item=None)


@app.route('/admin-panel/admit-cards/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def admin_admit_cards_edit(id):
    db = get_db()
    item = db.execute("SELECT * FROM admit_cards WHERE id = ?", (id,)).fetchone()
    if not item:
        abort(404)
    if request.method == 'POST':
        db.execute(
            "UPDATE admit_cards SET exam_name=?, release_date=?, admit_card_link=?, official_website=?, instructions=? WHERE id=?",
            (request.form.get('exam_name'), request.form.get('release_date'), request.form.get('admit_card_link'),
             request.form.get('official_website'), request.form.get('instructions'), id)
        )
        db.commit()
        flash('Admit card updated!', 'success')
        return redirect(url_for('admin_admit_cards'))
    return render_template('admin/admit_card_form.html', item=item)


@app.route('/admin-panel/admit-cards/delete/<int:id>', methods=['POST'])
@login_required
def admin_admit_cards_delete(id):
    db = get_db()
    db.execute("DELETE FROM admit_cards WHERE id = ?", (id,))
    db.commit()
    flash('Admit card deleted!', 'success')
    return redirect(url_for('admin_admit_cards'))


# ----- Current Affairs CRUD -----
@app.route('/admin-panel/current-affairs')
@login_required
def admin_current_affairs():
    db = get_db()
    items = db.execute("SELECT * FROM current_affairs ORDER BY affair_date DESC").fetchall()
    return render_template('admin/current_affairs.html', affairs=items)


@app.route('/admin-panel/current-affairs/add', methods=['GET', 'POST'])
@login_required
def admin_current_affairs_add():
    if request.method == 'POST':
        db = get_db()
        db.execute(
            "INSERT INTO current_affairs (title, description, important_facts, affair_date) VALUES (?, ?, ?, ?)",
            (request.form.get('title'), request.form.get('description'), request.form.get('important_facts'),
             request.form.get('affair_date'))
        )
        db.commit()
        flash('Current affair added!', 'success')
        return redirect(url_for('admin_current_affairs'))
    return render_template('admin/current_affair_form.html', item=None)


@app.route('/admin-panel/current-affairs/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def admin_current_affairs_edit(id):
    db = get_db()
    item = db.execute("SELECT * FROM current_affairs WHERE id = ?", (id,)).fetchone()
    if not item:
        abort(404)
    if request.method == 'POST':
        db.execute(
            "UPDATE current_affairs SET title=?, description=?, important_facts=?, affair_date=? WHERE id=?",
            (request.form.get('title'), request.form.get('description'), request.form.get('important_facts'),
             request.form.get('affair_date'), id)
        )
        db.commit()
        flash('Current affair updated!', 'success')
        return redirect(url_for('admin_current_affairs'))
    return render_template('admin/current_affair_form.html', item=item)


@app.route('/admin-panel/current-affairs/delete/<int:id>', methods=['POST'])
@login_required
def admin_current_affairs_delete(id):
    db = get_db()
    db.execute("DELETE FROM current_affairs WHERE id = ?", (id,))
    db.commit()
    flash('Current affair deleted!', 'success')
    return redirect(url_for('admin_current_affairs'))


# ----- Categories -----
@app.route('/admin-panel/categories')
@login_required
def admin_categories():
    db = get_db()
    items = db.execute("SELECT * FROM categories ORDER BY name").fetchall()
    return render_template('admin/categories.html', categories=items)


@app.route('/admin-panel/categories/add', methods=['GET', 'POST'])
@login_required
def admin_categories_add():
    if request.method == 'POST':
        name = request.form.get('name')
        slug = request.form.get('slug') or name.lower().replace(' ', '-').replace('&', 'and')
        db = get_db()
        try:
            db.execute(
                "INSERT INTO categories (name, slug, description, icon) VALUES (?, ?, ?, ?)",
                (name, slug, request.form.get('description'), request.form.get('icon', '📚'))
            )
            db.commit()
            flash('Category added!', 'success')
        except sqlite3.IntegrityError:
            flash('Category name or slug already exists!', 'danger')
        return redirect(url_for('admin_categories'))
    return render_template('admin/category_form.html', item=None)


@app.route('/admin-panel/categories/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def admin_categories_edit(id):
    db = get_db()
    item = db.execute("SELECT * FROM categories WHERE id = ?", (id,)).fetchone()
    if not item:
        abort(404)
    if request.method == 'POST':
        name = request.form.get('name')
        slug = request.form.get('slug') or name.lower().replace(' ', '-').replace('&', 'and')
        try:
            db.execute(
                "UPDATE categories SET name=?, slug=?, description=?, icon=? WHERE id=?",
                (name, slug, request.form.get('description'), request.form.get('icon', '📚'), id)
            )
            db.commit()
            flash('Category updated!', 'success')
        except sqlite3.IntegrityError:
            flash('Category name or slug already exists!', 'danger')
        return redirect(url_for('admin_categories'))
    return render_template('admin/category_form.html', item=item)


@app.route('/admin-panel/categories/delete/<int:id>', methods=['POST'])
@login_required
def admin_categories_delete(id):
    db = get_db()
    db.execute("DELETE FROM categories WHERE id = ?", (id,))
    db.commit()
    flash('Category deleted!', 'success')
    return redirect(url_for('admin_categories'))


# Error handlers
@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404


@app.errorhandler(500)
def internal_error(e):
    return render_template('500.html'), 500


if __name__ == '__main__':
    if not os.path.exists(DATABASE):
        init_db()
    else:
        # Ensure admin exists even if DB already there
        init_db()
    app.run(host='0.0.0.0', port=5000, debug=True)
